# 🚀 Deploy no Render.com (GRATUITO)

## Por que Render?
- ✅ 100% Gratuito
- ✅ Sem necessidade de cartão de crédito
- ✅ Fácil de usar
- ✅ URL pública automática
- ✅ SSL/HTTPS grátis

---

## 📋 Passo a Passo:

### **1. Criar conta no Render**
1. Acesse: https://render.com
2. Clique em "Get Started for Free"
3. Cadastre-se com Google ou GitHub

---

### **2. Fazer Upload do Código**

**Opção A - Com GitHub (Recomendado):**

1. Crie um repositório no GitHub
2. Faça upload dos arquivos:
   - server.js
   - package.json
   - render.yaml
3. No Render, clique em "New +" → "Web Service"
4. Conecte seu GitHub
5. Selecione o repositório
6. O Render vai detectar tudo automaticamente!
7. Clique em "Create Web Service"

**Opção B - Upload Manual:**

1. No Render Dashboard, clique em "New +" → "Web Service"
2. Escolha "Deploy from Git" ou "Deploy a Docker Image"
3. Conecte seu repositório ou faça upload manual

---

### **3. Configurações no Render**

O Render vai detectar automaticamente pelo `render.yaml`, mas se pedir:

- **Name:** visioncine-api
- **Runtime:** Node
- **Build Command:** `npm install`
- **Start Command:** `npm start`
- **Plan:** Free

---

### **4. Deploy!**

1. Clique em "Create Web Service"
2. Aguarde 2-3 minutos (ele vai instalar tudo)
3. Quando terminar, você verá: ✅ "Live"

---

### **5. Sua URL será:**

```
https://visioncine-api.onrender.com
```

Ou algo parecido! O Render gera automaticamente.

---

## 🧪 Testar a API:

Depois do deploy, teste:

```
https://sua-app.onrender.com/health
https://sua-app.onrender.com/api/search?q=matrix
https://sua-app.onrender.com/api/home
```

---

## ⚠️ IMPORTANTE - Plano Gratuito do Render:

- ✅ 750 horas/mês grátis (suficiente!)
- ⚠️ O app "dorme" após 15 min sem uso
- ⚠️ Primeira requisição pode demorar 30-60 segundos (acordar)
- ✅ Depois funciona normal!

---

## 🔄 Atualizar o código:

Basta fazer commit no GitHub que o Render atualiza automaticamente!

---

## 📱 Alternativas ao Render:

Se quiser testar outras opções gratuitas:

1. **Railway.app** - $5 grátis/mês
2. **Vercel** - Gratuito, ótimo para APIs
3. **Cyclic.sh** - Gratuito ilimitado
4. **Fly.io** - Gratuito com limites generosos

---

## ✅ Vantagens do Render sobre Discloud:

| Recurso | Discloud (Grátis) | Render (Grátis) |
|---------|-------------------|-----------------|
| Bots Discord | ✅ | ✅ |
| Sites/APIs | ❌ | ✅ |
| SSL/HTTPS | - | ✅ |
| Auto Deploy | ❌ | ✅ |
| Logs | ✅ | ✅ |

---

## 🆘 Precisa de ajuda?

Me avisa em qual etapa você está e eu te ajudo! 🚀

---

**Seu scraping vai funcionar perfeitamente no Render!** 🎉
